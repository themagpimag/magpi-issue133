# reBartender

## Intro

reBartender all starts with celebration of dragon boat festival at Seeed Studio, so why not host a booth to serve few drinks during the event with "reBartender V0.1" an automate cocktail mixer quickly assembled by Peter, even though he has no idea on cocktail mixer and does not like alcohol, he was so exciting about the project.
"re-" a prefix commonly used with the meaning "again", at Seeed Studio we created a product line called reThings to resemble “redefine” the product for future proof with well-considered customer’s requirements, Recently we have introduced a new reThings product called reTerminal DM (Device Master). it is a Panel PC, HMI, PLC, IIoT Gateway all-in-one device powered by Raspberry Pi CM4, with 10.1'' IP65 front panel and rich industrial interfaces, and natively integrated with Node-RED and supports Raspberry Pi-based software ecosystem. 
reTerminal DM has SenseCraft edge OS which has node-red built-in to make it more user friendly and much easier to get started in all kinds of industrial applications, also made this project possible to get realized in a short amount of time.


