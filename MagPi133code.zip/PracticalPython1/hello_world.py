# Outputs "Hello, World!" to the Shell
print("Hello, World!")